window.PanoraQRCode=require('qrcode');
